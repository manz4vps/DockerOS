import React, { useEffect, useState, useMemo } from 'react';
import { bytesToString, mbToBytes } from '@/lib/formatters';
import { ServerContext } from '@/state/server';
import { SocketEvent, SocketRequest } from '@/components/server/events';
import useWebsocketEvent from '@/plugins/useWebsocketEvent';
import RamGraph from '@/components/server/console/graphs/RamGraph';
import CPUGraph from '@/components/server/console/graphs/CPUGraph';
import styled from 'styled-components/macro';

const DetailsItem = styled.div`
    position: relative;
    background-color: var(--secondary);
    border-radius: var(--border-radius-items);
    height: 200px;
    overflow: hidden;
    z-index: 10;
    margin-bottom: 20px;

    &.long {
        max-height: 100%;
        height: auto;
    }

    & canvas {
        z-index: -1;
        position: absolute;
        bottom: -10px;
        max-height: 120px;
        width: calc(100% + 11px) !important;
        margin-left: -10px;
        left: 0;
    }

    & > .discription {
        padding: 20px 25px;
    }

    & > .discription > p {
        z-index: 10;
        font-size: 2em;
        font-weight: 700;
        letter-spacing: -1px;
    }

    & > .discription span {
        color: var(--color-4);
    }
`;

// --- DISK GRAPH (ANIMASI VERTIKAL / DARI BAWAH) ---
const DISKGraph = styled.div`
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%; /* Lebar Full */
    /* Height nanti gerak dinamis via script */
    border-top: 2px solid #3B6CDE; /* Garis di atas air */
    background-color: rgb(59, 108, 222, .5); /* Warna Air Biru */
    transition: height 0.5s ease-in-out; /* Animasi Gerak Naik Turun */
    z-index: -1;
`;

type Stats = Record<'memory' | 'cpu' | 'disk' | 'uptime' | 'rx' | 'tx', number>;

const SideGraph = () => {
    const [stats, setStats] = useState<Stats>({ memory: 0, cpu: 0, disk: 0, uptime: 0, tx: 0, rx: 0 });

    const connected = ServerContext.useStoreState(state => state.socket.connected);
    const instance = ServerContext.useStoreState(state => state.socket.instance);

    const statsListener = (data: string) => {
        let stats: any = {};
        try {
            stats = JSON.parse(data);
        } catch (e) {
            return;
        }

        setStats({
            memory: stats.memory_bytes,
            cpu: stats.cpu_absolute,
            disk: stats.disk_bytes,
            tx: stats.network.tx_bytes,
            rx: stats.network.rx_bytes,
            uptime: stats.uptime || 0,
        });
    };

    useEffect(() => {
        if (!connected || !instance) {
            return;
        }

        instance.addListener(SocketEvent.STATS, statsListener);
        instance.send(SocketRequest.SEND_STATS);

        return () => {
            instance.removeListener(SocketEvent.STATS, statsListener);
        };
    }, [instance, connected]);

    const limits = ServerContext.useStoreState((state) => state.server.data!.limits);

    const Limits = useMemo(
        () => ({
            cpu: limits?.cpu ? `${limits.cpu}%` : null,
            memory: limits?.memory ? bytesToString(mbToBytes(limits.memory)) : null,
            disk: limits?.disk ? bytesToString(mbToBytes(limits.disk)) : null,
        }),
        [limits]
    );

    // --- RUMUS FIX DISK (Supaya ngga full kalau kosong) ---
    const diskLimitBytes = limits?.disk ? (limits.disk * 1024 * 1024) : 0;
    const getDiskPercent = () => {
        if (diskLimitBytes === 0) return 0;
        let percent = (stats.disk / diskLimitBytes) * 100;
        // Minimal 0, Maksimal 100
        return Math.min(100, Math.max(0, percent));
    };

    return (
        <div className={`break-words`}>
            
            {/* KOTAK STATUS/NAMA SERVER SUDAH DIHAPUS DI SINI */}

            {/* RAM GRAPH */}
            <DetailsItem className={`w-full`}>
                <div className='discription'>
                    <p>{bytesToString(stats.memory)}</p>
                    <span>/ {Limits.memory || <>&infin;</>} ram</span>
                </div>
                <RamGraph />
            </DetailsItem>

            {/* CPU GRAPH */}
            <DetailsItem className={`w-full`}>
                <div className='discription'>
                    <p>{stats.cpu.toFixed(2)}%</p>
                    <span>/ {Limits.cpu || <>&infin;</>} CPU</span>
                </div>
                <CPUGraph />
            </DetailsItem>

            {/* DISK GRAPH (Fixed Vertical Animation) */}
            <DetailsItem className={`w-full`}>
                <div className='discription'>
                    <p>{bytesToString(stats.disk)}</p>
                    <span>/ {Limits.disk || <>&infin;</>} disk</span>
                </div>
                {/* Pakai HEIGHT untuk animasi bawah ke atas */}
                <DISKGraph style={{ height: `${getDiskPercent()}%` }} />
            </DetailsItem>
        </div>
    );
};

export default SideGraph;