import React, { useEffect, useState } from 'react';
import { ServerContext } from '@/state/server';
import { SocketEvent } from '@/components/server/events';
import useWebsocketEvent from '@/plugins/useWebsocketEvent';
import { Line } from 'react-chartjs-2';
import { useChartTickLabel } from '@/components/server/console/graphs/chart';

export default () => {
    const status = ServerContext.useStoreState((state) => state.status.value);
    const limits = ServerContext.useStoreState((state) => state.server.data!.limits);
    
    // Simpan nilai RAM terakhir (MB)
    const [currentMem, setCurrentMem] = useState(0);

    // INI YANG BIKIN WARNANYA TETAP ASLI (BAWAAN)
    const memory = useChartTickLabel('Memory', limits.memory, 'MB');

    useEffect(() => {
        if (status === 'offline') {
            memory.clear();
            setCurrentMem(0);
        }
    }, [status]);

    useWebsocketEvent(SocketEvent.STATS, (data: string) => {
        let values: any = {};
        try {
            values = JSON.parse(data);
        } catch (e) {
            return;
        }

        const memMb = Math.floor(values.memory_bytes / 1024 / 1024);
        memory.push(memMb);
        setCurrentMem(memMb); // Update tracker kita
    });

    return (
        <div className={`w-full`}>
            <Line
                {...memory.props} // Pakai props bawaan biar warna ga berubah
                options={{
                    ...memory.props.options,
                    scales: {
                        ...memory.props.options?.scales,
                        y: {
                            ...memory.props.options?.scales?.y,
                            // JURUS ANTI MENTOK RAM:
                            // Kalau usage > limit, atapnya naik otomatis + 15% space
                            max: limits.memory > 0 ? Math.max(limits.memory, currentMem) * 1.15 : undefined,
                            min: 0,
                            display: false,
                        },
                    },
                }}
            />
        </div>
    );
};