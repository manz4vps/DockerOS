import React, { useEffect, useState } from 'react';
import { ServerContext } from '@/state/server';
import { SocketEvent } from '@/components/server/events';
import useWebsocketEvent from '@/plugins/useWebsocketEvent';
import { Line } from 'react-chartjs-2';
import { useChartTickLabel } from '@/components/server/console/graphs/chart';

export default () => {
    const status = ServerContext.useStoreState((state) => state.status.value);
    const limits = ServerContext.useStoreState((state) => state.server.data!.limits);
    
    // Kita simpan nilai CPU terakhir biar bisa dihitung batas atasnya
    const [currentCpu, setCurrentCpu] = useState(0);

    // INI YANG BIKIN WARNANYA TETAP ASLI (BAWAAN)
    const cpu = useChartTickLabel('CPU', limits.cpu, '%', 2);

    useEffect(() => {
        if (status === 'offline') {
            cpu.clear();
            setCurrentCpu(0);
        }
    }, [status]);

    useWebsocketEvent(SocketEvent.STATS, (data: string) => {
        let values: any = {};
        try {
            values = JSON.parse(data);
        } catch (e) {
            return;
        }

        cpu.push(values.cpu_absolute);
        setCurrentCpu(values.cpu_absolute); // Update tracker kita
    });

    return (
        <div className={`w-full`}>
            <Line
                {...cpu.props} // Pakai props bawaan biar warna ga berubah
                options={{
                    ...cpu.props.options,
                    scales: {
                        ...cpu.props.options?.scales,
                        y: {
                            ...cpu.props.options?.scales?.y,
                            // JURUS ANTI MENTOK:
                            // Ambil yang paling gede (Limit vs Pemakaian) terus tambah 15% space
                            max: limits.cpu > 0 ? Math.max(limits.cpu, currentCpu) * 1.15 : undefined,
                            min: 0,
                            display: false,
                        },
                    },
                }}
            />
        </div>
    );
};