import React, { useEffect, useState, useMemo } from 'react';
import { ServerContext } from '@/state/server';
import { SocketEvent, SocketRequest } from '@/components/server/events';
import { bytesToString, mbToBytes } from '@/lib/formatters';
import RamGraph from '@/components/server/console/graphs/RamGraph';
import CPUGraph from '@/components/server/console/graphs/CPUGraph';
import styled, { css } from 'styled-components/macro';
import * as Icon from 'react-feather';
import tw from 'twin.macro';
import { Line } from 'react-chartjs-2';
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    Title,
    Tooltip,
    Legend,
    Filler
} from 'chart.js';

ChartJS.register(
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    Title,
    Tooltip,
    Legend,
    Filler
);

// --- STYLING ---

const Container = styled.div`
    width: 100%;
    margin-bottom: 1rem;
`;

const InfoCard = styled.div`
    ${tw`relative rounded p-5 w-full`};
    background-color: var(--secondary);
    border: 1px solid rgba(255,255,255,0.05);
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.2);
    display: flex;
    flex-direction: column;
    justify-content: center;
    min-height: 200px;
    margin-bottom: 1rem;
    
    @media (min-width: 768px) {
        flex-direction: row;
        justify-content: space-between;
        align-items: flex-start;
        padding: 1.5rem 3rem;
    }
`;

const LandscapeStats = styled.div`
    display: none;
    margin-top: 15px;
    padding-top: 15px;
    border-top: 1px solid rgba(255, 255, 255, 0.1);
    flex-direction: column;
    gap: 8px;

    @media (orientation: landscape) and (max-height: 600px) {
        display: flex;
    }
`;

const GraphsGrid = styled.div`
    display: grid;
    grid-template-columns: 1fr;
    gap: 1rem;
    width: 100%;

    @media (min-width: 1024px) {
        grid-template-columns: repeat(2, 1fr);
    }

    @media (orientation: landscape) and (max-height: 600px) {
        display: none !important;
    }
`;

const ServerTitle = styled.h2`
    font-size: 1.5rem;
    font-weight: 800;
    color: #fff;
    margin-bottom: 4px;
    letter-spacing: -0.5px;
`;

const InfoRow = styled.div`
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 8px;
    color: #d1d5db;
    font-size: 0.85rem;
    font-weight: 500;
    & svg { color: #6b7280; width: 16px; height: 16px; }
    & span.value { color: #fff; font-weight: 600; }
`;

const StatRow = styled(InfoRow)`
    margin-bottom: 4px;
    font-size: 0.8rem;
    & svg { width: 14px; height: 14px; color: #9ca3af; }
    & span.value { color: #e5e7eb; }
    & span.limit { color: #6b7280; font-size: 0.75rem; margin-left: 4px; }
`;

const StatusIndicator = styled.span<{ $status: string }>`
    color: ${props => 
        props.$status === 'running' ? '#10b981' : 
        props.$status === 'offline' ? '#ef4444' : '#f59e0b'};
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 0.9rem;
`;

const GraphCard = styled.div`
    ${tw`relative rounded p-6 overflow-hidden flex flex-col justify-between`};
    background-color: var(--secondary);
    height: 290px;
    border: 1px solid rgba(255,255,255,0.05);
    box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.3);
    width: 100%;
`;

const ChartContainer = styled.div`
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 100%;
    z-index: 0;
    opacity: 0.5;
    pointer-events: none;
    display: flex;
    align-items: flex-end;
    & > div, & canvas { width: 100% !important; height: 100% !important; }
`;

const DiskFill = styled.div`
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    background: linear-gradient(to top, rgba(59, 130, 246, 0.5), transparent);
    border-top: 2px solid #3b82f6;
    transition: height 0.8s cubic-bezier(0.4, 0, 0.2, 1);
    z-index: 0;
    opacity: 0.6;
`;

const Badge = styled.div<{ $mode?: 'danger' | 'warning' | 'normal' }>`
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 6px 12px;
    border-radius: 6px;
    font-size: 0.75rem;
    font-weight: 800;
    width: fit-content;
    z-index: 2;
    transition: all 0.3s ease;
    
    ${props => {
        switch (props.$mode) {
            case 'danger':
                return css`
                    background-color: rgba(239, 68, 68, 0.15);
                    color: #ef4444;
                    border: 1px solid rgba(239, 68, 68, 0.2);
                `;
            case 'warning':
                return css`
                    background-color: rgba(234, 179, 8, 0.15);
                    color: #eab308;
                    border: 1px solid rgba(234, 179, 8, 0.2);
                `;
            default:
                return css`
                    background-color: rgba(255, 255, 255, 0.05);
                    color: #9ca3af;
                    border: 1px solid rgba(255, 255, 255, 0.1);
                `;
        }
    }}
    & svg { width: 14px; height: 14px; }
`;

const StatText = styled.div`
    z-index: 2;
    margin-top: auto;
    padding-bottom: 5px;
    h3 {
        font-size: 1.8rem;
        font-weight: 900;
        color: #fff;
        margin: 0;
        line-height: 1;
        text-shadow: 0 4px 12px rgba(0,0,0,0.5);
    }
    p {
        font-size: 0.85rem;
        color: #d1d5db;
        margin-top: 4px;
        font-weight: 600;
        opacity: 0.9;
    }
`;

const NetworkStatBox = styled.div`
    margin-top: auto;
    z-index: 2;
    padding-bottom: 5px;
    display: flex;
    flex-direction: column;
    gap: 6px;
`;

const NetItem = styled.div`
    display: flex;
    align-items: center;
    gap: 10px;
    justify-content: space-between;
    
    .label-grp {
        display: flex;
        align-items: center;
        gap: 8px;
        .icon-box {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 24px;
            height: 24px;
            border-radius: 4px;
            background-color: rgba(255, 255, 255, 0.05);
            color: #9ca3af;
        }
        span { font-size: 0.7rem; color: #9ca3af; font-weight: 700; text-transform: uppercase; }
    }
    span.value { font-size: 1rem; font-weight: 800; color: #fff; }
`;

type Stats = Record<'memory' | 'cpu' | 'disk' | 'uptime' | 'rx' | 'tx', number>;

const StatGraphs = () => {
    const [stats, setStats] = useState<Stats>({ memory: 0, cpu: 0, disk: 0, uptime: 0, tx: 0, rx: 0 });
    const [networkHistory, setNetworkHistory] = useState<{rx: number[], tx: number[]}>({ rx: Array(20).fill(0), tx: Array(20).fill(0) });

    const status = ServerContext.useStoreState(state => state.status.value);
    const connected = ServerContext.useStoreState(state => state.socket.connected);
    const instance = ServerContext.useStoreState(state => state.socket.instance);
    const limits = ServerContext.useStoreState((state) => state.server.data!.limits);
    
    const name = ServerContext.useStoreState(state => state.server.data!.name);
    const id = ServerContext.useStoreState(state => state.server.data!.id);
    const node = ServerContext.useStoreState(state => state.server.data!.node);
    const allocation = ServerContext.useStoreState(state => {
        const match = state.server.data!.allocations.find((b) => b.isDefault);
        return !match ? 'n/a' : `${match.alias || match.ip}:${match.port}`;
    });

    const Limits = useMemo(() => ({
        cpu: limits?.cpu ? `${limits.cpu}%` : null,
        memory: limits?.memory ? bytesToString(mbToBytes(limits.memory)) : null,
        disk: limits?.disk ? bytesToString(mbToBytes(limits.disk)) : null,
    }), [limits]);

    const memoryLimitBytes = limits?.memory ? mbToBytes(limits.memory) : 0;
    const diskLimitBytes = limits?.disk ? mbToBytes(limits.disk) : 0;
    const diskPercent = diskLimitBytes > 0 ? (stats.disk / diskLimitBytes) * 100 : 0;

    const formatUptime = (ms: number) => {
        const seconds = Math.floor(ms / 1000);
        const h = Math.floor(seconds / 3600);
        const m = Math.floor((seconds % 3600) / 60);
        const s = seconds % 60;
        return `${h}h ${m}m ${s}s`;
    };

    const statsListener = (data: string) => {
        let stats: any = {};
        try { stats = JSON.parse(data); } catch (e) { return; }
        setStats({
            memory: stats.memory_bytes, cpu: stats.cpu_absolute, disk: stats.disk_bytes,
            tx: stats.network.tx_bytes, rx: stats.network.rx_bytes, uptime: stats.uptime || 0,
        });
        setNetworkHistory(prev => ({
            rx: [...prev.rx.slice(1), stats.network.rx_bytes],
            tx: [...prev.tx.slice(1), stats.network.tx_bytes]
        }));
    };

    useEffect(() => {
        if (!connected || !instance) return;
        instance.addListener(SocketEvent.STATS, statsListener);
        instance.send(SocketRequest.SEND_STATS);
        return () => { instance.removeListener(SocketEvent.STATS, statsListener); };
    }, [instance, connected]);

    // HITUNG NILAI MAX TRAFFIC SEKARANG
    const maxNetworkVal = Math.max(...networkHistory.rx, ...networkHistory.tx);

    const networkChartOptions = {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: { enabled: false } },
        scales: { 
            x: { display: false }, 
            y: { 
                display: false, 
                min: 0,
                // FIX SCALE NETWORK:
                // Minimal scale 1MB (1024*1024). Jadi kalau traffic cuma KB, grafik bakal gepeng (bener).
                // Kalau traffic > 1MB, grafik auto scale naik + buffer 20%.
                max: Math.max(maxNetworkVal * 1.2, 1024 * 1024) 
            } 
        },
        elements: { point: { radius: 0 }, line: { tension: 0.3, borderWidth: 2 } },
        animation: { duration: 0 }
    };

    const networkChartData = {
        labels: Array(20).fill(''),
        datasets: [
            { data: networkHistory.rx, borderColor: '#3b82f6', backgroundColor: 'rgba(59, 130, 246, 0.2)', fill: true },
            { data: networkHistory.tx, borderColor: '#f97316', backgroundColor: 'rgba(249, 115, 22, 0.2)', fill: true }
        ]
    };

    // --- LOGIC WARNA BADGE ---
    const getCpuMode = () => {
        if (!limits?.cpu || limits.cpu === 0) return 'normal';
        const percent = (stats.cpu / limits.cpu) * 100;
        if (percent >= 90) return 'danger';
        if (percent >= 75) return 'warning';
        return 'normal';
    };
    
    const getRamMode = () => {
        if (memoryLimitBytes === 0) return 'normal';
        const percent = (stats.memory / memoryLimitBytes) * 100;
        if (percent >= 90) return 'danger';
        if (percent >= 75) return 'warning';
        return 'normal';
    };

    const getDiskMode = () => {
        if (diskLimitBytes === 0) return 'normal';
        const percent = (stats.disk / diskLimitBytes) * 100;
        if (percent >= 90) return 'danger';
        if (percent >= 75) return 'warning';
        return 'normal';
    };

    return (
        <Container>
            
            <InfoCard>
                <div className="w-full">
                    <div style={{marginBottom: '10px'}}>
                        <ServerTitle>{name}</ServerTitle>
                        <StatusIndicator $status={status || 'offline'}>
                            <Icon.Activity size={16}/> 
                            {status === 'running' ? 'Online' : status === 'offline' ? 'Offline' : 'Starting...'}
                        </StatusIndicator>
                    </div>
                    
                    <div className="flex flex-col gap-1">
                        <InfoRow><Icon.Globe /> <span className="value">{allocation}</span></InfoRow>
                        <InfoRow><Icon.Hash /> <span className="value">{id}</span></InfoRow>
                        <InfoRow><Icon.Server /> <span className="value">{node}</span></InfoRow>
                        <InfoRow><Icon.Clock /> <span className="value">{stats.uptime > 0 ? formatUptime(stats.uptime) : '-'}</span></InfoRow>
                    </div>

                    <LandscapeStats>
                        <StatRow>
                            <Icon.Cpu /> 
                            <span className="value">{stats.cpu.toFixed(2)}%</span>
                            <span className="limit">/ {Limits.cpu || '100%'}</span>
                        </StatRow>
                        <StatRow>
                            <Icon.Server /> 
                            <span className="value">{bytesToString(stats.memory)}</span>
                            <span className="limit">/ {Limits.memory || 'Unlim'}</span>
                        </StatRow>
                        <StatRow>
                            <Icon.HardDrive /> 
                            <span className="value">{bytesToString(stats.disk)}</span>
                            <span className="limit">/ {Limits.disk || 'Unlim'}</span>
                        </StatRow>
                    </LandscapeStats>
                </div>
            </InfoCard>

            <GraphsGrid>
                
                {/* CPU CARD */}
                <GraphCard>
                    <Badge $mode={getCpuMode()}>
                        <Icon.Cpu /> CPU load
                    </Badge>
                    <StatText>
                        <h3>{stats.cpu.toFixed(2)}%</h3>
                        <p>/ {Limits.cpu || '100%'} Limit</p>
                    </StatText>
                    <ChartContainer><CPUGraph /></ChartContainer>
                </GraphCard>

                {/* MEMORY CARD */}
                <GraphCard>
                    <Badge $mode={getRamMode()}>
                        <Icon.Server /> Memory
                    </Badge>
                    <StatText>
                        <h3>{bytesToString(stats.memory)}</h3>
                        <p>/ {Limits.memory || 'Unlimited'}</p>
                    </StatText>
                    <ChartContainer><RamGraph /></ChartContainer>
                </GraphCard>

                {/* DISK CARD */}
                <GraphCard>
                    <Badge $mode={getDiskMode()}>
                        <Icon.HardDrive /> Disk
                    </Badge>
                    <StatText>
                        <h3>{bytesToString(stats.disk)}</h3>
                        <p>/ {Limits.disk || 'Unlimited'}</p>
                    </StatText>
                    <div style={{ position: 'absolute', bottom: 0, left: 0, width: '100%', height: '100%', zIndex: 0, pointerEvents: 'none' }}>
                        <DiskFill style={{ height: `${Math.min(diskPercent, 100)}%` }} />
                    </div>
                </GraphCard>

                {/* NETWORK CARD */}
                <GraphCard>
                    <Badge $mode="normal">
                        <Icon.Activity /> Network
                    </Badge>
                    <NetworkStatBox>
                        <NetItem>
                            <div className="label-grp">
                                <div className="icon-box"><Icon.ArrowDown size={14}/></div>
                                <span>Inbound</span>
                            </div>
                            <span className="value">{bytesToString(stats.rx)}</span>
                        </NetItem>
                        <div className="w-full h-px bg-gray-700/50"></div>
                        <NetItem>
                            <div className="label-grp">
                                <div className="icon-box"><Icon.ArrowUp size={14}/></div>
                                <span>Outbound</span>
                            </div>
                            <span className="value">{bytesToString(stats.tx)}</span>
                        </NetItem>
                    </NetworkStatBox>
                    <ChartContainer><Line data={networkChartData} options={networkChartOptions} /></ChartContainer>
                </GraphCard>

            </GraphsGrid>

        </Container>
    );
};

export default StatGraphs;