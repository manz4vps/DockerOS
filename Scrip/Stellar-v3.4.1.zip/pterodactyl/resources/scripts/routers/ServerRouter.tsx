import TransferListener from '@/components/server/TransferListener';
import React, { useEffect, useState } from 'react';
import { NavLink, Route, Switch, useRouteMatch } from 'react-router-dom';
import NavigationBarServer from '@/components/NavigationBarServer';
import TransitionRouter from '@/TransitionRouter';
import WebsocketHandler from '@/components/server/WebsocketHandler';
import { ServerContext } from '@/state/server';
import { CSSTransition } from 'react-transition-group';
import Can from '@/components/elements/Can';
import Spinner from '@/components/elements/Spinner';
import { NotFound, ServerError } from '@/components/elements/ScreenBlock';
import { httpErrorToHuman } from '@/api/http';
import { useStoreState } from 'easy-peasy';
import SubNavigation from '@/components/elements/SubNavigation';
import Alert from '@/components/elements/custom/Alert';
import InstallListener from '@/components/server/InstallListener';
import ErrorBoundary from '@/components/elements/ErrorBoundary';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faExternalLinkAlt } from '@fortawesome/free-solid-svg-icons';
import { useLocation } from 'react-router';
import ConflictStateRenderer from '@/components/server/ConflictStateRenderer';
import ContentContainer from '@/components/elements/ContentContainer';
import PermissionRoute from '@/components/elements/PermissionRoute';
import routes from '@/routers/routes';
import styled from 'styled-components/macro';
import CollapseBtn from '@/components/elements/custom/CollapseBtn';
import SearchContainer from '@/components/dashboard/search/SearchContainer';
import TopElement from '@/components/server/console/TopElement';
import { Navigation, ComponentLoader } from '@/routers/ServerElements';

const ContainerBlock = styled.div`
    display:flex;
    width:100%;

    & > .contentBlock{
        width:100%;
    }
    @media only screen and (max-width:979px){
      &{
          display:block;
      }
      & .collapseBtn{
          display:none;
      }
    }
`;

// --- MENU MODERN: STICKY + SCROLLBAR TEBAL ---
const MobileNavScroll = styled.div`
    display: none;
    
    @media only screen and (max-width: 979px) {
        display: flex;
        width: 100%;
        background-color: var(--secondary);
        
        /* STICKY HEADER */
        position: sticky;
        top: 0;
        z-index: 100;
        box-shadow: 0 4px 15px rgba(0,0,0,0.3); /* Bayangan container lebih kuat */

        /* SCROLL SAMPING */
        overflow-x: auto;
        white-space: nowrap;
        padding-bottom: 4px; /* Ruang buat scrollbar tebal */
        
        /* --- STYLE GARIS PANJANG (SCROLLBAR) --- */
        &::-webkit-scrollbar {
            height: 5px; /* DIPERBESAR: Dulu 3px, Sekarang 5px */
            display: block !important;
        }
        &::-webkit-scrollbar-track {
            background: rgba(255, 255, 255, 0.05); /* Warna Jalur */
        }
        &::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.2); /* Warna Slider */
            border-radius: 10px;
        }
    }
`;

// --- ITEM MENU (GLOWING BLUE) ---
const MobileNavItem = styled(NavLink)`
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 14px 18px;
    margin-right: 5px;
    color: #94a3b8;
    font-weight: 800; /* Font lebih tebal */
    font-size: 0.85rem;
    text-decoration: none;
    position: relative;
    transition: all 0.3s ease;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    border-bottom: 2px solid transparent;

    /* KONDISI AKTIF: MENYALA (GLOWING) */
    &.active {
        color: var(--primary);
        background: linear-gradient(to top, rgba(var(--primary), 0.1), transparent);
        
        /* EFEK GLOWING PADA TEKS */
        text-shadow: 0 0 10px rgba(var(--primary), 0.6);
        
        /* GARIS BAWAH MENYALA */
        border-bottom: 2px solid var(--primary);
    }

    /* EFEK GLOWING PADA GARIS BAWAH */
    &.active::after {
        content: '';
        position: absolute;
        bottom: -2px; /* Numpuk pas di scrollbar */
        left: 0;
        width: 100%;
        height: 2px;
        background: var(--primary);
        box-shadow: 0 0 10px var(--primary), 0 0 5px var(--primary); /* CAHAYA NEON */
        z-index: 10;
    }
`;

export default () => {
    const match = useRouteMatch<{ id: string }>();
    const location = useLocation();

    const rootAdmin = useStoreState((state) => state.user.data!.rootAdmin);
    const [error, setError] = useState('');

    const id = ServerContext.useStoreState((state) => state.server.data?.id);
    const uuid = ServerContext.useStoreState((state) => state.server.data?.uuid);
    const inConflictState = ServerContext.useStoreState((state) => state.server.inConflictState);
    const serverId = ServerContext.useStoreState((state) => state.server.data?.internalId);
    
    // Data Permission Check
    const nestId = ServerContext.useStoreState((state) => state.server.data?.nestId);
    const eggId = ServerContext.useStoreState((state) => state.server.data?.eggId);

    const getServer = ServerContext.useStoreActions((actions) => actions.server.getServer);
    const clearServerState = ServerContext.useStoreActions((actions) => actions.clearServerState);

    const to = (value: string, url = false) => {
        return `${(url ? match.url : match.path).replace(/\/*$/, '')}/${value.replace(/^\/+/, '')}`;
    };

    useEffect(
        () => () => {
            clearServerState();
        },
        []
    );

    useEffect(() => {
        setError('');

        getServer(match.params.id).catch((error) => {
            console.error(error);
            setError(httpErrorToHuman(error));
        });

        return () => {
            clearServerState();
        };
    }, [match.params.id]);

    return (
        <React.Fragment key={'server-router'}>
            
            {/* CSS: HIDE SIDEBAR ASLI & FIX STICKY */}
            <style>
            {`
                @media only screen and (max-width: 979px) {
                    .SubNavigation, div[css*="--subnavigation"] {
                        display: none !important;
                    }
                    .contentBlock {
                        padding-left: 0 !important;
                    }
                    /* Fix Sticky Behavior */
                    body { overflow-x: hidden; }
                }
            `}
            </style>

            <ContainerBlock>
                <NavigationBarServer />
                
                {/* === MENU MODERN (GLOWING + BIG SCROLLBAR) === */}
                {uuid && id && !error && (
                    <MobileNavScroll>
                        {routes.server
                            .filter((route) => !!route.name)
                            .map((route) => 
                                ((route.nestIds && route.nestIds.includes(nestId ?? 0)) ||
                                (route.eggIds && route.eggIds.includes(eggId ?? 0)) ||
                                (route.nestId && route.nestId === nestId) ||
                                (route.eggId && route.eggId === eggId) ||
                                (!route.eggIds && !route.nestIds && !route.nestId && !route.eggId)) && (
                                    route.permission ? (
                                        <Can key={route.path} action={route.permission} matchAny>
                                            <MobileNavItem to={to(route.path, true)} exact={route.exact}>
                                                <span>{route.name}</span>
                                            </MobileNavItem>
                                        </Can>
                                    ) : (
                                        <MobileNavItem key={route.path} to={to(route.path, true)} exact={route.exact}>
                                            <span>{route.name}</span>
                                        </MobileNavItem>
                                    )
                                )
                            )
                        }
                    </MobileNavScroll>
                )}
                {/* ============================================= */}

                <div className='contentBlock'>
                    {!uuid || !id ? (
                        error ? (
                            <ServerError message={error} />
                        ) : (
                            <Spinner size={'large'} centered />
                        )
                    ) : (
                        <>
                            <CSSTransition timeout={150} classNames={'fade'} appear in>
                                <ContentContainer>
                                    <SubNavigation>
                                        <div>
                                            <div className='collapseBtn'>
                                                <CollapseBtn/>
                                            </div>
                                            <SearchContainer/>
                                        </div>
                                        <div css='display:var(--subnavigation) !important;'>
                                            <Navigation />
                                            {rootAdmin && (
                                                <a href={`/admin/servers/view/${serverId}`} target={'_blank'}>
                                                    <FontAwesomeIcon icon={faExternalLinkAlt} />
                                                </a>
                                            )}
                                        </div>
                                    </SubNavigation>
                                    <Alert/>
                                </ContentContainer>
                            </CSSTransition>
                            <InstallListener />
                            <TransferListener />
                            <WebsocketHandler />
                            {inConflictState && (!rootAdmin || (rootAdmin && !location.pathname.endsWith(`/server/${id}`))) ? (
                                <ConflictStateRenderer />
                            ) : (
                                <ErrorBoundary>
                                  <TransitionRouter>
                                    <div className={'mt-4 sm:mt-10'}>
                                        <ContentContainer className={'mb-4'} css='display:var(--infoelement)!important;' >
                                            <TopElement/> 
                                        </ContentContainer>
                                    </div>
                                    <Switch location={location}>
                                      <ComponentLoader />
                                      <Route path={'*'} component={NotFound} />
                                    </Switch>
                                  </TransitionRouter>
                                </ErrorBoundary>
                            )}
                        </>
                    )}
                </div>
            </ContainerBlock>
        </React.Fragment>
    );
};