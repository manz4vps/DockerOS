<?php

namespace Pterodactyl\Http\Controllers\Admin\Arix;

use Illuminate\Http\RedirectResponse;
use Pterodactyl\Http\Requests\Admin\Arix\ArixComponentsRequest;

class ArixComponentsController extends BaseArixController
{
    protected function viewName(): string
    {
        return 'admin.arix.components';
    }

    protected function routeName(): string
    {
        return 'admin.arix.components';
    }

    public function store(ArixComponentsRequest $request): RedirectResponse
    {
        return $this->storeConfig($request, 'Arix component settings have been updated successfully.');
    }
}
