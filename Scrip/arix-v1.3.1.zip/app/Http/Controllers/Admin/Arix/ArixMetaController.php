<?php

namespace Pterodactyl\Http\Controllers\Admin\Arix;

use Illuminate\Http\RedirectResponse;
use Pterodactyl\Http\Requests\Admin\Arix\ArixMetaRequest;

class ArixMetaController extends BaseArixController
{
    protected function viewName(): string
    {
        return 'admin.arix.meta';
    }

    protected function routeName(): string
    {
        return 'admin.arix.meta';
    }

    public function store(ArixMetaRequest $request): RedirectResponse
    {
        return $this->storeConfig($request, 'Arix meta settings have been updated successfully.');
    }
}
