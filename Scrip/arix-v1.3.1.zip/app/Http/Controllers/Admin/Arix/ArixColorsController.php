<?php

namespace Pterodactyl\Http\Controllers\Admin\Arix;

use Illuminate\Http\RedirectResponse;
use Pterodactyl\Http\Requests\Admin\Arix\ArixColorsRequest;

class ArixColorsController extends BaseArixController
{
    protected function viewName(): string
    {
        return 'admin.arix.colors';
    }

    protected function routeName(): string
    {
        return 'admin.arix.colors';
    }

    public function store(ArixColorsRequest $request): RedirectResponse
    {
        return $this->storeConfig($request, 'Arix color settings have been updated successfully.');
    }
}
