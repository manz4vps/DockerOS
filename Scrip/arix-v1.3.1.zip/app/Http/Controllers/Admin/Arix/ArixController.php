<?php

namespace Pterodactyl\Http\Controllers\Admin\Arix;

use Illuminate\Http\RedirectResponse;
use Pterodactyl\Http\Requests\Admin\Arix\ArixRequest;

class ArixController extends BaseArixController
{
    protected function viewName(): string
    {
        return 'admin.arix.index';
    }

    protected function routeName(): string
    {
        return 'admin.arix';
    }

    public function store(ArixRequest $request): RedirectResponse
    {
        return $this->storeConfig($request, 'Arix settings have been updated successfully.');
    }
}
