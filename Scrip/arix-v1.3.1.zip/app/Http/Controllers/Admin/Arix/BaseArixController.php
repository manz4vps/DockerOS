<?php

namespace Pterodactyl\Http\Controllers\Admin\Arix;

use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\File;
use Illuminate\View\View;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Http\Requests\Admin\AdminFormRequest;

abstract class BaseArixController extends Controller
{
    public function __construct(
        protected AlertsMessageBag $alert,
    ) {
    }

    abstract protected function viewName(): string;

    abstract protected function routeName(): string;

    public function index(): View
    {
        return view($this->viewName(), config('arix'));
    }

    protected function storeConfig(AdminFormRequest $request, string $successMessage): RedirectResponse
    {
        $current = config('arix', []);
        $updated = $current;

        foreach ($request->normalize() as $key => $value) {
            if (!str_starts_with($key, 'arix:')) {
                continue;
            }

            $configKey = substr($key, 5);
            if (!array_key_exists($configKey, $current)) {
                continue;
            }

            $updated[$configKey] = $this->castValue($value, $current[$configKey]);
        }

        $this->writeConfig($updated);

        // If Laravel config cache exists, remove it so updated arix.php is loaded immediately.
        $cachedConfigPath = base_path('bootstrap/cache/config.php');
        if (File::exists($cachedConfigPath)) {
            File::delete($cachedConfigPath);
        }

        foreach ($updated as $key => $value) {
            config()->set("arix.$key", $value);
        }

        $this->alert->success($successMessage)->flash();

        return redirect()->route($this->routeName());
    }

    /**
     * @param array<string, mixed> $config
     */
    protected function writeConfig(array $config): void
    {
        $lines = ['<?php', '', 'return ['];

        foreach ($config as $key => $value) {
            $lines[] = sprintf("    '%s' => %s,", $key, var_export($value, true));
        }

        $lines[] = '];';
        $lines[] = '';

        File::put(config_path('arix.php'), implode("\n", $lines));
    }

    protected function castValue(mixed $value, mixed $currentValue): mixed
    {
        if (is_bool($currentValue)) {
            if (is_bool($value)) {
                return $value;
            }

            if ($value === null) {
                return false;
            }

            return in_array(strtolower((string) $value), ['1', 'true', 'yes', 'on'], true);
        }

        if (is_int($currentValue)) {
            return (int) $value;
        }

        if (is_float($currentValue)) {
            return (float) $value;
        }

        if ($value === null && is_string($currentValue)) {
            return '';
        }

        return $value;
    }
}
