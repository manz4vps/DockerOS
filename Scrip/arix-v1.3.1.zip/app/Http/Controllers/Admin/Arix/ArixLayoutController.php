<?php

namespace Pterodactyl\Http\Controllers\Admin\Arix;

use Illuminate\Http\RedirectResponse;
use Pterodactyl\Http\Requests\Admin\Arix\ArixLayoutRequest;

class ArixLayoutController extends BaseArixController
{
    protected function viewName(): string
    {
        return 'admin.arix.layout';
    }

    protected function routeName(): string
    {
        return 'admin.arix.layout';
    }

    public function store(ArixLayoutRequest $request): RedirectResponse
    {
        return $this->storeConfig($request, 'Arix layout settings have been updated successfully.');
    }
}
