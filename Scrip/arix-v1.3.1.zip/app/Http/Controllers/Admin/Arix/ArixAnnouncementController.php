<?php

namespace Pterodactyl\Http\Controllers\Admin\Arix;

use Illuminate\Http\RedirectResponse;
use Pterodactyl\Http\Requests\Admin\Arix\ArixAnnouncementRequest;

class ArixAnnouncementController extends BaseArixController
{
    protected function viewName(): string
    {
        return 'admin.arix.announcement';
    }

    protected function routeName(): string
    {
        return 'admin.arix.announcement';
    }

    public function store(ArixAnnouncementRequest $request): RedirectResponse
    {
        return $this->storeConfig($request, 'Arix announcement settings have been updated successfully.');
    }
}
