<?php

namespace Pterodactyl\Http\Controllers\Admin\Arix;

use Illuminate\Http\RedirectResponse;
use Pterodactyl\Http\Requests\Admin\Arix\ArixMailRequest;

class ArixMailController extends BaseArixController
{
    protected function viewName(): string
    {
        return 'admin.arix.mail';
    }

    protected function routeName(): string
    {
        return 'admin.arix.mail';
    }

    public function store(ArixMailRequest $request): RedirectResponse
    {
        return $this->storeConfig($request, 'Arix mail settings have been updated successfully.');
    }
}
