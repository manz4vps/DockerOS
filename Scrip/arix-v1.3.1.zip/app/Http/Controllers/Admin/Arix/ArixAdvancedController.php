<?php

namespace Pterodactyl\Http\Controllers\Admin\Arix;

use Illuminate\Http\RedirectResponse;
use Pterodactyl\Http\Requests\Admin\Arix\ArixAdvancedRequest;

class ArixAdvancedController extends BaseArixController
{
    protected function viewName(): string
    {
        return 'admin.arix.advanced';
    }

    protected function routeName(): string
    {
        return 'admin.arix.advanced';
    }

    public function store(ArixAdvancedRequest $request): RedirectResponse
    {
        return $this->storeConfig($request, 'Arix advanced settings have been updated successfully.');
    }
}
