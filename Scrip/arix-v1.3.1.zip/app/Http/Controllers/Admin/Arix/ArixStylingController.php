<?php

namespace Pterodactyl\Http\Controllers\Admin\Arix;

use Illuminate\Http\RedirectResponse;
use Pterodactyl\Http\Requests\Admin\Arix\ArixStylingRequest;

class ArixStylingController extends BaseArixController
{
    protected function viewName(): string
    {
        return 'admin.arix.styling';
    }

    protected function routeName(): string
    {
        return 'admin.arix.styling';
    }

    public function store(ArixStylingRequest $request): RedirectResponse
    {
        return $this->storeConfig($request, 'Arix styling settings have been updated successfully.');
    }
}
