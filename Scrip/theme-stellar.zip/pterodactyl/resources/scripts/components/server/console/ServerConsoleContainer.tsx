import React, { memo } from 'react';
import { ServerContext } from '@/state/server';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import isEqual from 'react-fast-compare';
import Spinner from '@/components/elements/Spinner';
import Features from '@feature/Features';
import Console from '@/components/server/console/Console';
import ServerDetailsBlock from '@/components/server/console/ServerDetailsBlock';
import SideGraph from '@/components/server/console/SideGraph'; // << INI GRAFIK YANG LU SUKA
import { Alert } from '@/components/elements/alert';
import { Server_is_transferred, Server_is_installing, Node_is_maintenance } from '@/lang';

export type PowerAction = 'start' | 'stop' | 'restart' | 'kill';

const ServerConsoleContainer = () => {
    const isInstalling = ServerContext.useStoreState((state) => state.server.isInstalling);
    const isTransferring = ServerContext.useStoreState((state) => state.server.data!.isTransferring);
    const eggFeatures = ServerContext.useStoreState((state) => state.server.data!.eggFeatures, isEqual);
    const isNodeUnderMaintenance = ServerContext.useStoreState((state) => state.server.data!.isNodeUnderMaintenance);

    return (
        <ServerContentBlock title={'Console'}>
            
            {/* Bagian Top (Bawaan Script Original) */}
            <div css='display:var(--graphcard) !important;'>
                <ServerDetailsBlock/>
            </div>

            <div className={'flex flex-wrap lg:flex-nowrap'}>
                
                {/* DULU: <SideGraphDiv> ... </SideGraphDiv> (Di Sini)
                   SEKARANG: DIHAPUS. Biar console jadi lebar full.
                */}

                <div className={'w-full mt-4 lg:mt-0'}>
                    
                    {/* 1. CONSOLE */}
                    <Spinner.Suspense>
                        <Console />
                    </Spinner.Suspense>

                    {(isNodeUnderMaintenance || isInstalling || isTransferring) && (
                        <Alert type={'warning'} className='mt-3'>
                            {isNodeUnderMaintenance
                                ? `${Node_is_maintenance}`
                                : isInstalling
                                ? `${Server_is_installing}`
                                : `${Server_is_transferred}`}
                        </Alert>
                    )}

                    {/* DULU: <StatGraphs /> (Grafik Bawah Lama) -> DIHAPUS.
                       SEKARANG: Diganti sama SideGraph di bawah ini.
                    */}

                    {/* 2. GRAFIK SAMPING (SideGraph) -> PINDAH KE SINI (BAWAH) */}
                    <div className={'mt-4 w-full'}>
                        <SideGraph />
                    </div>

                </div>
            </div>
            <Features enabled={eggFeatures} />
        </ServerContentBlock>
    );
};

export default memo(ServerConsoleContainer, isEqual);
